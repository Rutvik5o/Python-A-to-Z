a = 34

b = 2

# Conditional Operators 
print(a>4)
print(a<4)
print(a<=4)
print(a>=4)
print(a==4) # Is a equal to 4?
print(a==34) # Is a equal to 34?
print(a!=34) # Is a not equal to 34?