a = 32
print(a)
a*=3
print(a)