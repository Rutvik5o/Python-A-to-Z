c = True 
d = False

# Logical Operators
print(True and True)
print(True and False)
print(False and True)
print(False and False)

print("For Or Operator...")
print(True or True)
print(True or False)
print(False or True)
print(False or False)

print("Not Operator")
print(not(True) ) 
print(not(False) ) 