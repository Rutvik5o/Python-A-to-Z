# a = input("Enter first number") 
# a = int(a) # convert a to int version of a
# print(a + 3)

a = int(input("Enter first number"))
# a = int(a)
b = int(input("Enter second number"))
# b = int(b)

print(a + b)