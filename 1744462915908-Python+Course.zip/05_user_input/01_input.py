a = input("Enter a number")
print(a)

b = input("Enter your name: ")
print(b)