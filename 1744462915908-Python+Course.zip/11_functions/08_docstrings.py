def sum(a, b): 
    '''This will sum two numbers'''
    c = a + b  
    return c

print(sum.__doc__)