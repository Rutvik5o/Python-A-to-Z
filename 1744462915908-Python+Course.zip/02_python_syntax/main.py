print("Hello Harry")
print("I am good")
print("How are you?")
print(3)

# if(a>3):
#     statement1
#     statement3
# statement2