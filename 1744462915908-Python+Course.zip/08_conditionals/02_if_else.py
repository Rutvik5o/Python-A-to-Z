age = int(input("Enter your age: "))

if(age>18):
    print("You can drive")
else:
    print("You cannot drive")

print("End of program")