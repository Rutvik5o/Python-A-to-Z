age = 12

if(age>18):
    print("You can drive")
    print("Thank you ")

print("End of program")