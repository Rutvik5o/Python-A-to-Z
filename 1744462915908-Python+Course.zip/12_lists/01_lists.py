marks = [54, 23, 64, 93, 32]
mixed = [43, "Hello", False, 4.2]

print(marks[2:4])
print(marks[2])
print(mixed[4]) # Error Index out of bound