t = (3, 12, 1, 54, 23, 12)

print(t.count(12))
print(t.index(12))