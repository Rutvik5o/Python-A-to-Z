tu = (3, 2, 45)

a, b, c = tu 

print(a, b, c)