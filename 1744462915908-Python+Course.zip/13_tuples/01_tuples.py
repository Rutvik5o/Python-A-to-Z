a = (3, 2, 22, 13)

print(a)
print(a[2])
a[3] = 32

b = (3, )