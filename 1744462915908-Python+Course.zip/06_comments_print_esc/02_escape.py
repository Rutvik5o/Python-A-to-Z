print("Hey how are you\nI am good\\newline")

print("Hello \" World")