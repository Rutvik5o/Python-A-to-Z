print("Hey how are you?")

# Arjun please finish this code 


# Rohan, please review what arjun has done
'''
mments are used to explain code and are ignored by the Python
interpreter.
Single-line comments start with # .
Multi-line comments are enclosed in  or """ .
Escape Sequences
Escape sequences are used to include special characters in strings.
Common escape sequences:
\n : Newline
\t : Tab
\\ : Backslash
\" : Double quote
\' : Single quote
Example:
Print Statement
The print() function is used to display output.
•
•
•
# This is a single
'''