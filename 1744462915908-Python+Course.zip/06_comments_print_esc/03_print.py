# print('Hello World',"Harry",5, sep="/")
print('Hello World', end="..")
print('Harry', end="//")