# print(1)
# print(2)
# print(3)
# print(4)
# print(5)

# for i in range(1, 6): # range function goes from 1 to (6-1) ie 5 in this case
#     print(i)

for i in range(1, 11):
    print("5 X", i, "=",  5*i)