# print(1)
# print(2)
# print(3)
# print(4)
# print(5)

i = 1
while i<6:
    print(i)
    i = i + 1