i = 3

if i == 32:
    pass # do nothing
print("End of program")