for i in range(1, 20):
    if i == 10:
        continue # continue the loop for the next iteration here itself
    print(i)

    