for i in range(0, 21):
    print(i)
    if i == 11:
        break # Cancel the execution of this loop now