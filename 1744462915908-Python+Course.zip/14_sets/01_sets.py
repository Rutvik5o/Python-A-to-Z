s = {3, 23, 2, 11}

print(s, type(s))
# print(s[3]) # You are not allowed to do something like this