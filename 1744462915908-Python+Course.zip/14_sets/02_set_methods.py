s = {34, 23, 1, 3, 22}

print(s)

s.add(32)
s.add(322)
s.remove(1)
# s.remove(434234) # Throws an error
s.discard(42323)
print(s)