# v1 - package 1 (pandas)
# v2 - package 2 (numpy)
# v3 - package 3 (moviepy)
#  ".\env2\Scripts\Activate.ps1" (To activate env2)

import moviepy