f = open("harry.txt", "r")

for line in f:
    print(line)

f.close()