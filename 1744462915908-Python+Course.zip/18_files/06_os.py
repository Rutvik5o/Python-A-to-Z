import os 


a = os.listdir("dir")
print(a)
print(os.getcwd())
print(os.path.exists("harry"))
# os.remove("sample.txt")
os.rmdir("dir")