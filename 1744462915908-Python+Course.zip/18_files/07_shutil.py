import shutil

# shutil.rmtree("dir")
# shutil.copy("harry.txt", "john.txt")

shutil.move("john.txt", "dir/")