f = open("harry.txt", "r")

content = f.read()

print(content)

f.close()