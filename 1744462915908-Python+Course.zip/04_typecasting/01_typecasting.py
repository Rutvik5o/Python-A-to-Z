a = 34 
b = "34"
d = 223


print(a)
print(type(a))

print(b)
print(type(b))

# Convert b to an integer
c = int(b)
print(c)
print(type(c))

e = str(d)
print(e)
print(type(e))