# name = "Harry"
name = 'Harry'
# name = '''Harry is a good boy'''
print(name)