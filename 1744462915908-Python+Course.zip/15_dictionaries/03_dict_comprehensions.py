table_of_5 = {i: 5*i for i in range(1, 11)}

print(table_of_5)