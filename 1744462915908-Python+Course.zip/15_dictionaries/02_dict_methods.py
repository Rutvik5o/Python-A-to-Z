marks = {"harry": 34, "jack": 45, "lily": 94 }

print(marks.keys())
print(marks.values())
# marks.clear()
marks.pop("lily")
print(marks)
