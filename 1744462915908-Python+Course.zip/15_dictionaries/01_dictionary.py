marks = {"harry": 34, "jack": 45, "lily": 94 }

# print(marks, type(marks))
print(marks["lily"])
marks["harry"] = 3
print(marks)